package th.ac.airconditionerservice.comment

class ChatMessage(val  text:String, val fromId:String){
    constructor(): this("","")
}